package com.aiaddcited.eurekatestclient;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class RibbonClient {
    //Because @LoadBalanced and @Bean exist in main app class, Spring automatically injects
    // Ribbon enabled Rest template.
    @Autowired
    RestTemplate restTemplate;

    @HystrixCommand(fallbackMethod = "contactBackupServer",
            threadPoolKey = "licenseByOrgThreadPool")
    @RequestMapping("/contactserver")
    public String contactserver() {
        String url = "http://SERVICEA/contact";
        return restTemplate.getForObject(url, String.class);
    }

    public String contactBackupServer() {
        return "This is to show how to do FALLBACK and BULKHEAD with Hystrix";
    }

}

